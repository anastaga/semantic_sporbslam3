#include "YoloDetection.h" // Include your header

#include <iostream>
#include <algorithm>
#include <onnxruntime_cxx_api.h>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/dnn.hpp>
#include <opencv2/highgui.hpp>

static const std::vector<std::string> coco_class_names = {
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe",
    "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard",
    "sports ball", "kite", "baseball bat", "baseball glove", "skateboard", "surfboard",
    "tennis racket", "bottle", "wine glass", "cup", "fork", "knife", "spoon", "bowl",
    "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog", "pizza",
    "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table", "toilet",
    "tv", "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven",
    "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
    "hair drier", "toothbrush"
};

YoloV8Detector::YoloV8Detector(const std::string& modelPath, float confThreshold, float nmsThreshold)
    : confThreshold_(confThreshold), nmsThreshold_(nmsThreshold) {

    env_ = Ort::Env(ORT_LOGGING_LEVEL_WARNING, "YoloV8");

    Ort::SessionOptions sessionOptions;
    sessionOptions.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);

#ifdef USE_CUDA
    OrtCUDAProviderOptions cudaOptions;
    cudaOptions.device_id = 0;
    sessionOptions.AppendExecutionProvider_CUDA(cudaOptions);
#endif

    Ort::AllocatorWithDefaultOptions allocator;
    session_ = std::make_unique<Ort::Session>(env_, modelPath.c_str(), sessionOptions);

    Ort::AllocatedStringPtr input_name_ptr = session_->GetInputNameAllocated(0, allocator);
    Ort::AllocatedStringPtr output_name_ptr = session_->GetOutputNameAllocated(0, allocator);
inputName_ = std::string(input_name_ptr.get());
outputName_ = std::string(output_name_ptr.get());


    Ort::TypeInfo inputTypeInfo = session_->GetInputTypeInfo(0);
    auto inputTensorInfo = inputTypeInfo.GetTensorTypeAndShapeInfo();
    inputDims_ = inputTensorInfo.GetShape();

    if (inputDims_[2] == -1 || inputDims_[3] == -1) {
        inputDims_[2] = 640;
        inputDims_[3] = 640;
    }

    Ort::TypeInfo outputTypeInfo = session_->GetOutputTypeInfo(0);
    auto outputTensorInfo = outputTypeInfo.GetTensorTypeAndShapeInfo();
    outputDims_ = outputTensorInfo.GetShape();
}


    
YoloV8Detector::~YoloV8Detector() {

}

    
    // Perform object detection on a BGR image. Returns detections (filtering to persons class 0).
std::vector<Detection> YoloV8Detector::detect(const cv::Mat& imageBGR) {
    // Preprocess: resize + pad to 640x640, normalize, convert to RGB
    int targetSize = static_cast<int>(inputDims_[2]);
    int originalWidth = imageBGR.cols;
    int originalHeight = imageBGR.rows;
    float scale = std::min(targetSize * 1.0f / originalWidth, targetSize * 1.0f / originalHeight);
    int newWidth = static_cast<int>(std::round(originalWidth * scale));
    int newHeight = static_cast<int>(std::round(originalHeight * scale));

    cv::Mat resized, padded;
    cv::resize(imageBGR, resized, cv::Size(newWidth, newHeight));
    int pad_x = (targetSize - newWidth) / 2;
    int pad_y = (targetSize - newHeight) / 2;
    int pad_right = targetSize - newWidth - pad_x;
    int pad_bottom = targetSize - newHeight - pad_y;
    cv::copyMakeBorder(resized, padded, pad_y, pad_bottom, pad_x, pad_right, cv::BORDER_CONSTANT, cv::Scalar(114, 114, 114));

    // Convert to float32 RGB planar
    cv::Mat floatImg;
    padded.convertTo(floatImg, CV_32F, 1.0 / 255.0);
    if (floatImg.channels() == 3) {
    cv::cvtColor(floatImg, floatImg, cv::COLOR_BGR2RGB);
} else if (floatImg.channels() == 1) {
    // Handle grayscale (e.g. replicate to 3-channel RGB)
    cv::cvtColor(floatImg, floatImg, cv::COLOR_GRAY2RGB);
} else {
    throw std::runtime_error("Unsupported number of channels in input image.");
}

    cv::cvtColor(floatImg, floatImg, cv::COLOR_BGR2RGB);
    std::vector<cv::Mat> channels(3);
    cv::split(floatImg, channels);

    std::vector<float> inputTensorValues(3 * targetSize * targetSize);
    size_t channelSize = targetSize * targetSize;
    for (int c = 0; c < 3; ++c) {
        memcpy(inputTensorValues.data() + c * channelSize, channels[c].data, channelSize * sizeof(float));
    }

    // Create input tensor
    std::array<int64_t, 4> inputShape = {1, 3, targetSize, targetSize};
    Ort::MemoryInfo memoryInfo = Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault);
    Ort::Value inputTensor = Ort::Value::CreateTensor<float>(memoryInfo, inputTensorValues.data(), inputTensorValues.size(), inputShape.data(), inputShape.size());

    // Run inference
    std::vector<const char*> inputNames  = { inputName_.c_str() };
    std::vector<const char*> outputNames = { outputName_.c_str() };
    auto outputTensors = session_->Run(Ort::RunOptions{nullptr}, inputNames.data(), &inputTensor, 1, outputNames.data(), 1);

    // Get output
    float* outputData = outputTensors.front().GetTensorMutableData<float>();
    int numDetections = outputTensors.front().GetTensorTypeAndShapeInfo().GetShape()[1];  // [1, N, 6]

    std::vector<Detection> detections;
    for (int i = 0; i < numDetections; ++i) {
        float x = outputData[i * 6 + 0];
        float y = outputData[i * 6 + 1];
        float w = outputData[i * 6 + 2];
        float h = outputData[i * 6 + 3];
        float conf = outputData[i * 6 + 4];
        int cls = static_cast<int>(outputData[i * 6 + 5]);

        // Map back from 640x640 to original image space
        float left   = (x - w / 2.0f - pad_x) / scale;
        float top    = (y - h / 2.0f - pad_y) / scale;
        float right  = (x + w / 2.0f - pad_x) / scale;
        float bottom = (y + h / 2.0f - pad_y) / scale;

        left = std::max(0.0f, std::min(left, static_cast<float>(originalWidth)));
        top = std::max(0.0f, std::min(top, static_cast<float>(originalHeight)));
        right = std::max(0.0f, std::min(right, static_cast<float>(originalWidth)));
        bottom = std::max(0.0f, std::min(bottom, static_cast<float>(originalHeight)));

        if (cls == 0 || cls == 2 || cls == 16) {  // person, car, dog
            Detection det;
            det.classId = cls;
            det.confidence = conf;
            det.label = coco_class_names[cls];
            det.box = cv::Rect(cv::Point(static_cast<int>(std::round(left)), static_cast<int>(std::round(top))),
                               cv::Point(static_cast<int>(std::round(right)), static_cast<int>(std::round(bottom))));
            detections.push_back(det);
        }
    }
    return detections;
}


